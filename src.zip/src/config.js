

module.exports = {
	spreadSheetVui : {
		googleApiKey : 'AIzaSyAXQAai7bhCIp_OzCB4eOcFmiZ0veFGlgg',
		googleSheetId : '1XYLxeRL-XuNbw709KnKAYNmXUZ1GjPonYsszo8JVPKk'
	}
};

