/**
 * Created by sashthecash on 21/06/2017.
 */

const
  AlexaComplexAnswer = require('./sensory/alexa/AlexaComplexAnswer'),
  lodash = require('lodash')

class Execution {

  /**  @param {AlexaRequestVO} alexaRequest */
  static exec (alexaRequest) {
    return Promise.resolve(alexaRequest)
      .then(Execution.handleIntent)
      .then(alexaRequest => {
        alexaRequest.answer = AlexaComplexAnswer.buildComplexAnwser(alexaRequest)
        return alexaRequest
      })
  }


  /**  @param {AlexaRequestVO} alexaRequestVO */
  static handleIntent (alexaRequest) {

    // vui implementation magic 3 lines! Dont Touch!
    if (alexaRequest.reqSessionData.subIntent &&
      alexaRequest.reqSessionData.subIntent[alexaRequest.intentName]) {
      alexaRequest.intentName = alexaRequest.reqSessionData.subIntent[alexaRequest.intentName]
    }

    let intentMethod = alexaRequest.intentName

    // alexaRequest.vReq     = {}; // data extracted out of the request
    // alexaRequest.vRes     = {}; // data generated to answer
    // alexaRequest.vResLoop = {}; // data generated to answer in loops

    /** check if a Method exists – named like the intent.. */
    return (typeof Execution[intentMethod] === 'function') ?
      Execution[intentMethod](alexaRequest) :
      Execution.GenericVuiRequest(alexaRequest)
  }


  /**  @param {AlexaRequestVO} alexaRequestVO */
  static SessionEndedRequest (alexaRequest) {

    let usersx = alexaRequest.getPermanent('userObject') || {userName: ''}
    alexaRequest.vRes = usersx
    return new Promise(resolve => resolve(alexaRequest))
  }

  /**  @param {AlexaRequestVO} alexaRequestVO */
  static ProfilName (alexaRequest) {
    let name = alexaRequest.slots['profilVar']
    let userObj = alexaRequest.savePermanent('userObject', {userName: name})
    alexaRequest.vRes = userObj

    return new Promise(resolve => resolve(alexaRequest))


  }

  /**  @param {AlexaRequestVO} alexaRequestVO */
  static LaunchRequest (alexaRequest) {

    let usersx = alexaRequest.getPermanent('userObject')

    if (usersx === undefined) {
      console.log('lange antwort')
    }
    else {
      console.log('\n \n Username: ' + usersx + '\n')
      alexaRequest.intentName = 'SecondStartIntent'
      alexaRequest.vRes = usersx
    }

    return new Promise(resolve => resolve(alexaRequest))
  }

  /**  @param {AlexaRequestVO} alexaRequestVO */
  static AskWorkoutsIntent (alexaRequest) {
    let userObject = alexaRequest.getPermanent('userObject') || {userName: 'tobi'}
    if (userObject.currentExercise !== undefined ){
      userObject.currentExercise ++}
    else {
        userObject.currentExercise = 0
    }

    alexaRequest.savePermanent('userObject', userObject)

    console.log('userObject' , userObject)

    alexaRequest.vRes = Object.assign(userObject, alexaRequest.dataBase[userObject.currentExercise])

    return new Promise(resolve => resolve(alexaRequest))
  }


  /**  @param {AlexaRequestVO} alexaRequestVO */
  static NextIntent (alexaRequest) {
    let userObject = alexaRequest.getPermanent('userObject') || {userName: 'tobi'}
      console.log('Current User', userObject)

      if (userObject.currentExercise !== undefined ) {

          ++ userObject.currentExercise }
    else {
        userObject.currentExercise = 0
          console.log('Aktuelle Aufgabe'+ userObject.currentExercise)
    }

      console.log('Current Exercise: ' + userObject.currentExercise)

    alexaRequest.savePermanent('userObject', userObject)

    console.log('userObject', userObject)

      if(userObject.currentExercise == alexaRequest.dataBase.length ) {
      // send cards
          return new Promise(resolve => resolve(alexaRequest))

      }


    // check if exersice exisits
    let exercise = alexaRequest.dataBase[userObject.currentExercise]
    if (!exercise) {
      alexaRequest.intentName = 'StopIntent'
      alexaRequest.vRes = userObject
    } else {
      // { userName: Tobi, exersiceName: kjdf}
      alexaRequest.vRes = Object.assign({}, userObject, exercise)
    }
    return new Promise(resolve => resolve(alexaRequest))
  }

  /**  @param {AlexaRequestVO} alexaRequestVO */
  static AskExercise (alexaRequest) {

    let exerciseName = alexaRequest.slots['exercise']
    let keyed = lodash.keyBy(alexaRequest.dataBase, 'exerciseName')


    let askedExcercise = keyed[exerciseName]

    console.log('askedExcercise1', askedExcercise)
    if ( askedExcercise ) {
      let decription = askedExcercise.exerciseDescription
    }

    console.log('keyed', keyed)
    console.log('askedExcercise2', askedExcercise)
    console.log('exerciseDescription', decription)


    //let explainJumpingJack = alexaRequest.dataBase[0].Description

    alexaRequest.vRes = {exercise : askedExcercise}
    return new Promise(resolve => resolve(alexaRequest))
  }

/*
  /!**  @param {AlexaRequestVO} alexaRequestVO *!/
  static AskCrunchesIntent (alexaRequest) {
    let explainCrunches = alexaRequest.dataBase[1].Description

    alexaRequest.vRes = {exerciseCrunches: explainCrunches}
    return new Promise(resolve => resolve(alexaRequest))
  }

  /!**  @param {AlexaRequestVO} alexaRequestVO *!/
  static AskSquadsIntent (alexaRequest) {
    let explainSquads = alexaRequest.dataBase[2].Description

    alexaRequest.vRes = {exerciseSquads: explainSquads}
    return new Promise(resolve => resolve(alexaRequest))
  }

  /!**  @param {AlexaRequestVO} alexaRequestVO *!/
  static AskPushUpsIntent (alexaRequest) {
    let explainPushUps = alexaRequest.dataBase[3].Description

    alexaRequest.vRes = {exercisePushUps: explainPushUps}
    return new Promise(resolve => resolve(alexaRequest))
  }*/



  /**  @param {AlexaRequestVO} alexaRequestVO */
  static Endworkout (alexaRequest) {

    // alexaRequest.vRes = {exercises: 'aslkhj'}

    alexaRequest.card = {
      type: 'Standard', // Simple, Standard, LinkAccount
      title: 'Dein heutiges Trainingsergebniss',
      text: 'Datum: /n Bodypart: /n Dauer: /n Deine nächste Trainingssession am: /n',
      image: {
        smallImageUrl: 'https://image.ibb.co/b1b3ud/Gym_Me_Card.png',
        largeImageUrl: 'https://carfu.com/resources/card-images/race-car-large.png',
      }

    }
    return new Promise(resolve => resolve(alexaRequest))
  }











  /**@param {AlexaRequestVO} alexaRequestVO */
  static GenericVuiRequest (alexaRequest) {
    return new Promise(resolve => resolve(alexaRequest))
  }

}

module.exports = Execution
